
import asyncio

from fastapi.security import HTTPBasic, HTTPBasicCredentials

import sqlite3
import hypercorn
from hypercorn.asyncio import serve

asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

asyncio.DEFAULT_TIMEOUT = 60 


import time

from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi import Depends, FastAPI
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.encoders import jsonable_encoder
from fastapi import FastAPI, Request, HTTPException, status, Body, Depends, WebSocket
from fastapi.staticfiles import StaticFiles
security = HTTPBasic()
app = FastAPI()
from pydantic import BaseModel

conn = sqlite3.connect("db.db")
conn.row_factory = sqlite3.Row
cursor = conn.cursor()
from typing import Union
class Model(BaseModel):
    name: Union[str, None] = None
    date: Union[str, None] = None
    factoryNumber: Union[str, None] = None
    modelName:Union[str, None] = None
    orderName:Union[str, None] = None
    operationName:Union[str, None] = None
    workCenter:Union[str, None] = None
    workerNames:Union[str, None] = None
    masterCallerName:Union[str, None] = None
    controllerResponderName:Union[str, None] = None
    controllerDecisionMakerName:Union[str, None] = None
    status:Union[str, None] = None
    id:Union[int, None] = None
    timeMasterCalled:Union[str, None] = None
    timeControllerCalled:Union[str, None] = None
    controllerDecisionTime:Union[str, None] = None
    decision:Union[str, None] = None

@app.get("/",response_class=HTMLResponse)
async def root(request: Request):
    return FileResponse("index.html")
a = ['name', 'date', 'factoryNumber', 'modelName','orderName','operationName','workCenter', 'workerNames', 'masterCallerName', 'controllerResponderName', 'controllerDecisionMakerName', 'status', 'timeMasterCalled', 'timeControllerCalled']
@app.post("/alter")
async def alter(model: Model):

    cursor.execute(f"""
    UPDATE db
    SET name = ?, 
        date = ?, 
        factoryNumber = ?, 
        modelName = ?, 
        orderName = ?, 
        operationName = ?, 
        workCenter = ?, 
        workerNames = ?, 
        masterCallerName = ?, 
        controllerResponderName = ?, 
        controllerDecisionMakerName = ?, 
        status = ?, 
        timeControllerCalled = ?, 
        timeMasterCalled = ?,
        controllerDecisionTime = ?,
        decision = ?
    WHERE id = ?
    """, (
        model.name, 
        model.date, 
        model.factoryNumber, 
        model.modelName, 
        model.orderName, 
        model.operationName, 
        model.workCenter, 
        model.workerNames, 
        model.masterCallerName, 
        model.controllerResponderName, 
        model.controllerDecisionMakerName, 
        model.status, 
        model.timeControllerCalled, 
        model.timeMasterCalled, 
        model.controllerDecisionTime,
        model.decision,
        model.id
    ))
    conn.commit()
    

@app.post("/create")
async def alter(model: Model):

    cursor.execute(f"INSERT INTO db (name, date, factoryNumber, modelName,orderName,operationName,workCenter, workerNames, masterCallerName, controllerResponderName, controllerDecisionMakerName, status) VALUES ('{model.name}','{model.date}', '{model.factoryNumber}', '{model.modelName}','{model.orderName}','{model.operationName}','{model.workCenter}', '{model.workerNames}', '{model.masterCallerName}', '{model.controllerResponderName}', '{model.controllerDecisionMakerName}', '{model.status}');")
    conn.commit()

@app.get("/load")
async def root():

    a= cursor.execute(f"SELECT * FROM db")

    r = cursor.fetchall()

    return r



config = hypercorn.Config()
config.bind = ["localhost"]


asyncio.run(serve(app, config))